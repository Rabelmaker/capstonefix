package com.akbar.capstone2.screen.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.akbar.capstone2.R
import com.akbar.capstone2.model.FakeProductDataSource
import com.akbar.capstone2.model.WeatherModel
import com.akbar.capstone2.model.dummySlide
import com.akbar.capstone2.ui.component.ProductItem
import com.akbar.capstone2.ui.component.SlideItem
import com.akbar.capstone2.ui.component.Title
import com.akbar.capstone2.ui.component.TitleWithSeeAll
import com.akbar.capstone2.ui.component.WeatherCard

@Composable
fun HomeScreen(
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(enabled = true, state = rememberScrollState())
    ) {
        Banner()
        Title(title = "Around agriculture")
        SlideRow()
        TitleWithSeeAll(
            title = "Purchase land needs",
            description = "Complete, guaranteed, and original"
        )
        ProductRow()
    }
}

@Composable
fun Banner(
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
    ) {
        Image(
            painter = painterResource(R.drawable.banner),
            contentDescription = "Banner Image",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .height(200.dp)
                .fillMaxWidth()
        )
        Column(
            modifier = modifier
                .padding(16.dp)
                .align(Alignment.Center)
        ) {
            Text(
                text = "Hello Akbar Maulana",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Light,
                color = Color.White
            )
            Text(
                text = "it’s a sunny day!",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = modifier.padding(bottom = 16.dp)
            )
            WeatherCard(
                card = WeatherModel(
                    R.drawable.day,
                    "25°C",
                    "Pekanbaru, ",
                    "12:00 PM",
                    "50 %",
                    "10 m/s"
                ),
                modifier = modifier
            )
        }
    }
}

@Composable
fun SlideRow(
    modifier: Modifier = Modifier
) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        modifier = modifier
    ) {
        items(dummySlide, key = { it.textSlide }) { slide ->
            SlideItem(slide)
        }
    }
}

@Composable
fun ProductRow(
    modifier: Modifier = Modifier,

    ) {
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        modifier = modifier
    ) {
        items(FakeProductDataSource.dummyProduct, key = { it.id }) { product ->
            ProductItem(
                image = product.image,
                title = product.title,
                price = product.price
            )
        }
    }
}