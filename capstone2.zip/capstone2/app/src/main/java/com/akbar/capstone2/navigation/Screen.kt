package com.akbar.capstone2.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Recommend : Screen("recommend")
    object PestAnalysis : Screen("pest_analysis")
    object Market : Screen("market")
    object Cart : Screen("cart")
    object Profile : Screen("profile")
    object Login : Screen("login")
    object Register : Screen("register")
    object DetailProduct : Screen("home/{productId}") {
        fun createRoute(productId: Long) = "home/$productId"
    }
}