package com.akbar.capstone2.navigation

data class NavigationItem(
    val icon: Int,
    val title: String,
    val screen: Screen
)