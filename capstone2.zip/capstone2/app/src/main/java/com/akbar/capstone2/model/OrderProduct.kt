package com.akbar.capstone2.model

data class OrderProduct(
    val product: ProductModel,
    val count: Int
)