package com.akbar.capstone2.model

data class ProductModel(
    val id: Long,
    val image: Int,
    val title: String,
    val description : String,
    val price: Int,
)
