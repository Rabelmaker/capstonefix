package com.akbar.capstone2.model

import com.akbar.capstone2.R

data class ProfileModel(
    val imageSlide: Int,
)

val dummyProfile = listOf(
    ProfileModel(R.drawable.man),
)