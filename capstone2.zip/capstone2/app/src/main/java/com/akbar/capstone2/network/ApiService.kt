package com.akbar.capstone2.network

import com.akbar.capstone2.model.auth.ApiModel
import com.akbar.capstone2.model.auth.LoginModel
import com.akbar.capstone2.model.auth.RegisterModel
import com.akbar.capstone2.model.auth.UserModel
import retrofit2.http.*

interface ApiService {
    @POST("register")
    suspend fun register(@Body request: RegisterModel): ApiModel


    @POST("login")
    suspend fun login(@Body request: LoginModel): ApiModel

    @GET("user")
    suspend fun user(@Body request: UserModel): ApiModel
}
