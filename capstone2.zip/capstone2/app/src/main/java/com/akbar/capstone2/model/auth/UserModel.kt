package com.akbar.capstone2.model.auth

data class UserModel(
    val id: Int?,
    val name: String?,
    val email: String?,
    val no_hp : String?
)