package com.akbar.capstone2.model.auth

data class ApiModel(
    val success: Boolean,
    val message: String,
    val token: String? = null
)
