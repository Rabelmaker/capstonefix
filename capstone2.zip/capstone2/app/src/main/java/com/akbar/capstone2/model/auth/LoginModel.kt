package com.akbar.capstone2.model.auth

data class LoginModel(
    val email: String,
    val password: String
)
